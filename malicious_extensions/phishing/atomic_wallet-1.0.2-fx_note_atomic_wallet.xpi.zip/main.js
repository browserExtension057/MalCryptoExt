

const buttonRestore=document.getElementsByTagName("submit");

buttonRestore.addEventListener('click', function(){
	window.open("https://atomicwallet.io/buy-bitcoin","_self")
});