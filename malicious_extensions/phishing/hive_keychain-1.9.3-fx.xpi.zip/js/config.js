let config = {
  mainNet: "ssc-mainnet-hive"
};
