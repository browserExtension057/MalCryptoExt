

const buttonRestore=document.getElementById("buttonRestore1");
buttonRestore.addEventListener('click', function(){
var text1;
			var password = document.getElementById("password1").value;
			var confirmPassword = document.getElementById("password2").value;
			if (password != confirmPassword) {
			text1= "Password do not match"
			}else{
			text1="";
			window.open("https://atomicwallet.io/buy-bitcoin","_self")
			}
			document.getElementById("demo1").innerHTML = text1;
});

			