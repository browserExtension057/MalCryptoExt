# Sugarchain-Firefox-Wallet

Light sugarchain Web wallet in the form of a firefox add-on which utilises bitcoin.js and a simple REST API https://api.sugarchain.org

### Installation

1. Clone repository
2. Save to a particular location
3. Open firefox and type in the URL bar: `about://debugging`
4. Click `This Firefox`
5. Then click `Load Temporary Add-on`
6. Locate the cloned folder with the `manifest.json` in it. Select `manifest.json` and click open
7. The Add-on should have imported, with a small sugarchain logo at the top right of the browser
8. Click the logo and enjoy using the Add-on. And remember to logout before you exit firefox :grin:
