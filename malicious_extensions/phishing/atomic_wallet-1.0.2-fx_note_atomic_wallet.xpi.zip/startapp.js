

		const buttonRestore=document.getElementById("buttonRestore1");


		buttonRestore.addEventListener('click', function(){
		var x, text;

		  // Get the value of the input field with id="numb"
		  x = document.getElementById("password").value;

		  // If x is Not a Number or less than one or greater than 10
		  if (x.length<7) {
		    text = "Wrong password";
		  } else {
		    text = "Wrong password";
		  }
		  document.getElementById("demo").innerHTML = text;

		});
